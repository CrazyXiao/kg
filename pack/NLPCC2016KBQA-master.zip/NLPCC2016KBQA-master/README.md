# NLPCC2016KBQA
KBQA based on the NLPCC2016 dataset, including reimplementation of NLPCC2016 best team`s QA.

You can get the data from http://tcci.ccf.org.cn/conference/2017/taskdata.php
